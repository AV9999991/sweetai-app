# SweetAI App

一个前后端一体的 NFT Mint 平台。