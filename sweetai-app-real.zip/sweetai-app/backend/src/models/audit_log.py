class AuditLog:
    id: int
    action: str