class User:
    id: int
    name: str