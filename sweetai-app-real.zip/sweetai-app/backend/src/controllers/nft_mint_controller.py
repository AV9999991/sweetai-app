from fastapi import APIRouter

router = APIRouter()

@router.post("/mint")
def mint():
    return {"status": "minted"}