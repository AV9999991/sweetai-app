import React from "react";

const App = () => {
  return <h1>Welcome to SweetAI</h1>;
};

export default App;