module.exports = {
  apps: [
    {
      name: "frontend",
      script: "npm",
      args: "run dev",
      cwd: "./frontend"
    },
    {
      name: "backend",
      script: "uvicorn",
      args: "app:app --reload --host 0.0.0.0 --port 8000",
      cwd: "./backend"
    }
  ]
};